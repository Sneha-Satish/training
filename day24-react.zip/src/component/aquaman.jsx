function AquamanComp(){
    return (
      <div>
        <h2> Aquaman Component</h2>
      </div>
    );
    }

    export default AquamanComp;