import { Component } from "react";
import HeroComp from "./components/hero.component";
import HeroHookComp from "./components/hero.hook.comp";
import MovieComponent from "./components/movie.component";
import MovieHookComp from "./components/movie.hook.comp";

class App extends Component{
    render(){
        return <div>
            <h1> Hello Everyone</h1>
            <HeroComp/>
            <HeroHookComp/>
            <MovieComponent/>
            <MovieHookComp/>
            
        </div>
    }
}

export default App;