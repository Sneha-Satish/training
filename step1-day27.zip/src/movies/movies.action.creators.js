import { ADD_MOVIE, REMOVE_MOVIE } from "./movies.type"

const addmovie=()=>{
    return{
        type:ADD_MOVIE
    }
}

const removemovie=()=>{
    return{
        type:REMOVE_MOVIE
    }
}

export {addmovie,removemovie};