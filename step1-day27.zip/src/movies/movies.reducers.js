import { ADD_MOVIE, REMOVE_MOVIE } from "./movies.type"

const movieInitialState={
    numofMovies:0
}

const movieReducer=(state=movieInitialState,action)=>{
    switch(action.type){
        case ADD_MOVIE:return{...state,numofMovies:state.numofMovies+1}
        case REMOVE_MOVIE:return{...state,numofMovies:state.numofMovies-1}
        default:return state
    }
}

export {movieReducer};