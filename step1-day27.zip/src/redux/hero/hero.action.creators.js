import { ADD_HERO, REMOVE_HERO } from "./hero.type"

const addhero=()=>{
    return{
        type:ADD_HERO
    }
}

const removehero=()=>{
    return{
        type:REMOVE_HERO
    }
}

export {addhero,removehero};