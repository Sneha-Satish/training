// import { Component } from "react";
import {  useDispatch, useSelector } from "react-redux";
import { addmovie, removemovie } from "../movies/movies.action.creators";


let MovieHookComp=()=>{
    const numofMovieHook=useSelector(state=>state.movies.numofMovies);
    const dispatch=useDispatch();
    return <div>
        <h2> Movie Component</h2>
            <h3>Total Heroes Recruited:{numofMovieHook} </h3>
            <button onClick={()=>dispatch(addmovie())}>Add Movie</button>
            <button onClick={()=>dispatch(removemovie())}>Remove Movie</button>
    </div>
}
// class HeroComp extends Component{
//     render(){
//         return <div>
//             <h2> Hero Component</h2>
//             <h3>Total Heroes Recruited:{this.props.numberofHeroes} </h3>
//             <button onClick={this.props.addhero}>Add Hero</button>
//             <button onClick={this.props.removehero}>Remove Hero</button>
            
//         </div>
//     }
// }

// const mapStoreToProps=(state)=>{
//     return{
//        numberofHeroes:state.heroes.numofHeroes
//     }
// }

// const mapDispatchToProps=(dispatch)=>{
//     return{
//         addhero:()=> dispatch(addhero()),
//         removehero:()=> dispatch(removehero())
//     }
// }

export default MovieHookComp;