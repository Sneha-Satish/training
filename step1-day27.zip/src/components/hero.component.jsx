import { Component } from "react";
import { connect } from "react-redux";
import { addhero, removehero } from "../redux/hero/hero.action.creators";

class HeroComp extends Component{
    render(){
        return <div>
            <h2> Hero Component</h2>
            <h3>Total Heroes Recruited:{this.props.numberofHeroes} </h3>
            <button onClick={this.props.addhero}>Add Hero</button>
            <button onClick={this.props.removehero}>Remove Hero</button>
            
        </div>
    }
}

const mapStoreToProps=(state)=>{
    return{
       numberofHeroes:state.heroes.numofHeroes
    }
}

const mapDispatchToProps=(dispatch)=>{
    return{
        addhero:()=> dispatch(addhero()),
        removehero:()=> dispatch(removehero())
    }
}

export default connect (mapStoreToProps,mapDispatchToProps)(HeroComp);