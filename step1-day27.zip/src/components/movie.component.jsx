import { Component } from "react";
import { connect } from "react-redux";
import { addmovie,  removemovie,  } from "../movies/movies.action.creators";


class MovieComponent extends Component{
    render(){
        return <div>
            <h2> Movie Component</h2>
            <h3>Total Movies Recruited:{this.props.numberofMovies} </h3>
            <button onClick={this.props.addmovie}>Add Movie</button>
            <button onClick={this.props.removemovie}>Remove Movie</button>
            
        </div>
    }
}

const mapStoreToProps=(state)=>{
    return{
       numberofMovies:state.movies.numofMovies
    }
}

const mapDispatchToProps=(dispatch)=>{
    return{
        addmovie:()=> dispatch(addmovie()),
        removemovie:()=> dispatch(removemovie())
    }
}

export default connect (mapStoreToProps,mapDispatchToProps)(MovieComponent);