import { useContext } from "react";
import FamilyContext from "../Context/index1";

let ChildComp=()=>{
    let grandGift=useContext(FamilyContext);
    return <div style={{border:"2px solid yellow", margin:"10px",padding:"10px"}}>
        <h1> Child Component</h1>
        <h2>{grandGift}</h2>
        <h2>{grandGift}</h2>
        <h2>{grandGift}</h2>
        <h2>{grandGift}</h2>
        {/* <FamilyContext.Consumer>{(val)=><h2>Gift Received {val} </h2>}</FamilyContext.Consumer> */}
    </div>
}


export default ChildComp;