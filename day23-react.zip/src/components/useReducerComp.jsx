import { useReducer, useRef } from "react";


 let UseReducerComp=()=>{
    let fname=useRef()
    let lname=useRef()
    let cname=useRef()
//     let [firstname,setFirstname]=useState("");
let reducerFun=(state,action)=>{
    switch(action.type){
        case "UPDATE_FIRSTNAME":return {...state,firstname: action.payload}
        case "UPDATE_LASTNAME":return {...state,lastname: action.payload}
        case "UPDATE_CITYNAME":return {...state,cityname: action.payload}
        default:return state;
    }
}
let [state,dispatch]=useReducer(reducerFun,{firstname:'',lastname:'',cityname:''})
    return <div>
         <h3>UseReducer Hook Componet</h3>
         <input type="text" ref={fname}/>
         <button onClick={()=>dispatch({type:"UPDATE_FIRSTNAME" ,payload:fname.current.value})}> Set Firstname</button>
         <h3>Firstname:{state.firstname}</h3>
         <input type="text" ref={lname}/>
         <button onClick={()=>dispatch({type:"UPDATE_LASTNAME",payload:lname.current.value})}> Set Lastname</button>
         <h3>Lastname:{state.lastname}</h3>
         <input type="text" ref={cname}/>
         <button onClick={()=>dispatch({type:"UPDATE_CITYNAME",payload:cname.current.value})}> Set City name</button>
         <h3>Cityname:{state.cityname}</h3>
         </div>
}

export {UseReducerComp}