import { useState } from "react";
import FamilyContext from "../Context/index1";
import ParentComp from "./parent.component";

let GrandParentComp=()=>{
    let[gift,updateGift]=useState(0)
    return <div style={{border:"2px solid yellow", margin:"10px",paading:"10px"}}>
        <h1> GrandParent Component</h1>
        <button onClick={()=>updateGift(Math.round(Math.random()*100))}>Send Gifts</button>
        <FamilyContext.Provider value={gift}>
            <ParentComp/>
           
        </FamilyContext.Provider>
    </div>
}

export default GrandParentComp;