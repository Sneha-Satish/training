import { Component } from "react";
import UseStateAssignmentComp from "./component/usestate.components";



 
class App extends Component{
    state={
        apptitle:"HOOKS",
    }
    
    render(){
        return <div className="container">
            <h1>{this.state.apptitle}</h1>
            <UseStateAssignmentComp/>
            </div>
}}
 
export default App;
 
 
