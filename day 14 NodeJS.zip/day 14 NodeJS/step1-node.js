var message1="welcome to your company"
var message2=", nothing is impossible";
//console.log(message);
//console.log(__dirname);
module.exports.message1=message1;
module.exports.message2=message2;