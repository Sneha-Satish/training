module.exports={
    message:"welcome to my world"
}