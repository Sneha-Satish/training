var obj=require("./step1-node");
console.log(obj.message);