var message=require("sneha_satish").message;

console.log(message);