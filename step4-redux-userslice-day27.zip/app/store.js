const configureStore=require("@reduxjs/toolkit").configureStore;
const  logger  = require("redux-logger").createLogger;
const userReducer=require("../features/user/userSlices");

const store=configureStore({
    reducer:{
        user:userReducer
    },
    middleware:(getDefaultMiddleware)=>getDefaultMiddleware().concat(logger())
})

module.exports=store;
