const store=require("./app/store");

const fetchUsers=require("./features/user/userSlices").fetchUsers;

console.log("Initial State : " ,store.getState());

const unsubscribe=store.subscribe(()=>{})

store.dispatch(fetchUsers());
