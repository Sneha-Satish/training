import { Component } from "react";
import Hero from "./Hero";


class App extends Component{
    avengers=["Thor","Ironman","Hulk"]
    JusticeLeague=["Spiderman","batman","WonderWomen"]
    IndicHeros=["Krish","Sakthimon"]
    render(){
        return <div>
            <Hero list={this.avengers} version ={1} title="Avengers"> </Hero>
            <Hero list={this.JusticeLeague} version ={2} title="JusticeLeague"> </Hero>
            <Hero list={this.IndicHeros} version ={3} title="IndicHeros"> </Hero>
            
        </div>
    }
}

export default App