// import React from "react";
// import { Platform, StyleSheet,  Text,  View } from "react-native";



// const Flex = () => {
//   return (
//     <View style={[styles.container, {
     
//       flexDirection: "column"
//     }]}>
//       <View style={{ flex: 2,backgroundColor: "#ff006e" }} >
//       <Text style={{textAlign:"center",paddingTop:50, fontSize:50}}>Header</Text>
//       </View>
      
//       <View style={{ flex: 5,backgroundColor: "#f15bb5" }} >
//       <Text style={{textAlign:"center",paddingTop:120, fontSize:50}}>Main View</Text>
//       </View>
//       <View style={{ flex: 3,backgroundColor: "#ffafcc"}} >
//       <Text style={{textAlign:"center",paddingTop:100, fontSize:50}}>Footer</Text>
//       </View>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     paddingLeft:0,
//     paddingRight:0,
//     paddingBottom:0,
//     borderColor:"blue",
//     borderWidth:3,
//     paddingTop:Platform.OS==="android"&&50 || Platform.OS==="ios"&&60

//   },
// });



import React, { useState } from "react";
import { Platform, Pressable, StyleSheet,  Text,  View } from "react-native";

const App = () => {
  let [color,setColor]=useState("");
  return (
    <View style={[styles.container, {
      float:"left",
      alignItems:"stretch"
      
    }]}>
     <View style={[styles.container,{backgroundColor:color,}]}>
      <Pressable onPress={()=>setColor("#ff006e")}>
      <View style={{ width:100,height:100,backgroundColor: "#ff006e" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#f15bb5")}>
      <View style={{ width:100,height:100,backgroundColor: "#f15bb5" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#ffafcc")}>
      <View style={{width:100,height:100,backgroundColor: "#ffafcc"}} />
      </Pressable>
      <Pressable onPress={()=>setColor("aliceblue")}>
      <View style={{width:100,height:100,backgroundColor:"aliceblue"}} />
      </Pressable>
      </View>
     </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "row",
    alignItems:"flex-end",
    padding: 50,
    paddingLeft:0,
    paddingRight:0,
    paddingBottom:0,
    paddingTop:Platform.OS==="android"&&50 || Platform.OS==="ios"&&60

  },
});

export default App;

// import { useState } from "react";
// import ironman from "./images/ironman.jpg"
// import wonderwoman from "./images/wonderwoman.jpg"
// import blackpanther from "./images/blackpanther.jpg"
// import thor from "./images/thor.jpg"
// import { Button, Text,View,StyleSheet, Platform,Image } from "react-native";
// export default function Avengers(){

//   let [name,updateName] = useState({title:'',firstname:'',lastname:'',image:''})
//   let changeImage=( img )=>{
//     if(img ==="ironman"){
//       updateName({
//         title:"Ironman",
//         firstname:"Tony",
//         lastname:"Stark",
//         image:ironman
//       })
//     }
//     else if(img ==="thor"){
//        updateName({
//         title:"Thor",
//         firstname:"Thor",
//         lastname:"Odinson",
//         image:thor
//       })
//     }
//     else if(img ==="blackpanther"){
//       updateName({
//         title:"Blackpanther",
//         firstname:"T",
//         lastname:"Challa",
//         image:blackpanther
//       })
//     }
//     else{
//       updateName({
//         title:"wonderwoman",
//         firstname:"Diana",
//         lastname:"Princess",
//         image:wonderwoman
//       })
//     }
//   }
//   return(    
//     <View style={mystyle.viewstyle}>

//       <View>
//         <Text style={{fontSize:45, color: "crimson",padding:50}}>Avengers</Text>
//       </View>
//       <Text/>

//       <View>

//         <Text style={{fontSize:22}} >
//         Title : {name.title}{"\n"}  
//         Firstname: {name.firstname}{"\n"}
//         Lastname: {name.lastname}</Text>
//         <Image source={name.image}></Image>


//       <View>
//         <Button onPress={()=>changeImage("thor")} title="Thor" color={'blue'}></Button>
//         <Text>  </Text>
//         <Button onPress={()=>changeImage("blackpanther")} title="blackpanther" color={'black'}></Button>
//         <Text> </Text>
//       </View>
//       <View >
//         <Button onPress={()=>changeImage("ironman")} title="Ironman" color={'gold'}></Button> 
//         <Text> </Text>
//         <Button onPress={()=>changeImage("wonderwoman")} title="wonderwoman" color={'red'}></Button>
//         <Text> </Text>
      
//       </View>


//       </View>

//      </View>
   
//   )
// }
// let mystyle = StyleSheet.create({
//   viewstyle:{
//     flex:1,justifyContent:'center',alignItems:'center',paddingTop: Platform.OS ==="android"?30:0
//   }
// })

