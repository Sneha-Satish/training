import { useState } from "react";
import { BrowserRouter,  NavLink, Route, Routes } from "react-router-dom"
import React from "react";
// import AquamanComp from "./component/aquaman";
// import BatmanComp from "./component/batman";
// import HomeComp from "./component/home.component";
// import NotfoundComp from "./component/notfound.componet";
// import SupermanComp from "./component/superman";
// import WonderWomenComp from "./component/wonderwomen.component";
import "./myroutes.css"
import { Suspense } from "react";

let AquamanComp=React.lazy(()=>import("./component/aquaman"));
let BatmanComp=React.lazy(()=>import("./component/batman"));
let BatMovie1Comp=React.lazy(()=>import("./component/batMovie1.comp"))
let BatMovie2Comp=React.lazy(()=>import("./component/batMovie2.comp"))
let HomeComp=React.lazy(()=>import("./component/home.component"));
let NotfoundComp=React.lazy(()=>import("./component/notfound.componet"));
let SupermanComp=React.lazy(()=>import("./component/superman"));
let WonderWomenComp=React.lazy(()=>import("./component/wonderwomen.component"));


    function App() {
        let [quantity,SetQty]=useState(0)
        let activeFun1 = ({isActive})=> isActive ? 'box' : 'plainBox';
        let activeFun2 = ({isActive})=> {
          return {
            width: "200px",
            display: "inline-block",
            backgroundColor: isActive ? "crimson" : "darkorange",
            color:  "papayawhip",
            textAlign: "center",
            padding: "5px",
          }
        };
    return ( <div>
        <h2> React router Component 101 </h2>
        <label htmlFor="qty" > Set range </label>
        <input id="qty" value={quantity} type="range" onChange={(evt)=>SetQty(evt.target.value)}/>
        <BrowserRouter>
         {/* <ul>
            <li><Link to="/">Home Component</Link></li>
            <li><Link to="batman">Batman Component</Link></li>
            <li><Link to="superman">Superman Component</Link></li>
            <li><Link to="aquaman">Aquaman Component</Link></li>
            <li><Link to="wonderwomen">Wonder Women Component</Link></li>
            <li><Link to="flash">flash Component</Link></li>
            <li><Link to="cyborg">Cyborg Component</Link></li>
         </ul> */}

{/* <ul>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="/" end>Home Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="batman">Batman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="superman">Superman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="wonderwomen">Wonder Women Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="aquaman">Aquaman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="flash">Flash Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : '' } to="cyborg">Cyborg Component</NavLink></li>
        </ul> */}

         
<ul>
          <li><NavLink end className={activeFun1} to="/">Home Component</NavLink></li>
          <li><NavLink style={ activeFun2 } to="/batman">Batman Component</NavLink></li>
          <li><NavLink className={ activeFun1 } to="/batman/batMovie1">Batman Movie1</NavLink></li>
          <li><NavLink className={ activeFun1 } to="/batman/batMovie2">Batman Movie2</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box brdr' : 'plainBox' } to="/superman">Superman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/wonderwomen">Wonder Women Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to={"/wonderwomen/"+quantity}>Wonder Women Component with params</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/aquaman">Aquaman Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/flash">Flash Component</NavLink></li>
          <li><NavLink className={ ({isActive})=> isActive ? 'box' : 'plainBox' } to="/cyborg">Cyborg Component</NavLink></li>
        </ul>

        <Routes>
           
            <Route path="/" element={<HomeComp/>}/>
            <Route path="/batman" element={<Suspense fallback={<>loading...</>}> <BatmanComp/> </Suspense>}>
                <Route path="/batman/batMovie1" element={<Suspense fallback={<>loading...</>}> <BatMovie1Comp/> </Suspense>}></Route>
                <Route path="/batman/batMovie2" element={<Suspense> <BatMovie2Comp/> </Suspense>}></Route>
               
            </Route>
            <Route path="/superman" element={<Suspense fallback={<>loading...</>}> <SupermanComp/> </Suspense>}/>
            <Route path="/wonderwomen" element={<Suspense fallback={<>loading...</>}> <WonderWomenComp/></Suspense>}/>
            <Route path="/wonderwomen/:qty" element={<Suspense fallback={<>loading...</>}> <WonderWomenComp/></Suspense>}/>
            <Route path="/aquaman" element={<Suspense fallback={<>loading...</>}> <AquamanComp/></Suspense>}/>
            <Route path="/flash" element={<Suspense fallback={<>loading...</>}> <SupermanComp/></Suspense>} />
            <Route path="*" element={<Suspense fallback={<>loading...</>}> <NotfoundComp/> </Suspense>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;