function NotfoundComp(){
    return (
      <div>
        <h2> Not Found Component</h2>
      </div>
    );
    }

    export default NotfoundComp;