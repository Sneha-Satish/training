import {useParams} from "react-router-dom"

function WonderWomenComp(){
  let params=useParams()
    return (
      <div>
        <h2> WonderWomen Component</h2>
        <h3> Quantity is :{Number (params.qty)+10||0} </h3>
      </div>
    );
    }

    export default WonderWomenComp;