function BatMovie2Comp(){
    return (
      <div>
        <h2> BatMovie2 Component</h2>
      </div>
    );
    }

    export default BatMovie2Comp;