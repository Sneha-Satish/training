function BatMovie1Comp(){
    return (
      <div>
        <h2> BatMovie1 Component</h2>
      </div>
    );
    }

    export default BatMovie1Comp;