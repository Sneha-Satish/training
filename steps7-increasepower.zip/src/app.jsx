import { Component } from "react";
import ChildComp from "./child.component";

class App extends Component{
    render(){
        return <div>
           
            <ChildComp title="third component" power={8}> </ChildComp> 
            
            
        </div>
    }
}

export default App;
