import { func } from "prop-types";
import { Component } from "react";


class ChildComp extends Component{
    state={
        title:"Default Title",
        power:0
        
    }

    decreasePower=()=>{
        this.setState(function(currentState,currentProp){
            return{
                power:currentState.power-1
            }
        
        }, function(){
            console.log(this.state.power)
        });
    }
    render(){
        return <div>
                    <h1>Child Component | Power is {this.state.power} </h1>
                    <button onClick={this.decreasePower}>Increase Power</button>
        </div>
    }

  
        }
    

    
export default ChildComp;