
let redux = require("redux");
let createStore = redux.legacy_createStore;
let process=require("process");
let fs=require("fs")

let data=`firstname ${process.argv[2]} \n lastname ${process.argv[3]} \n power ${process.argv[4]} \n version ${process.argv[5]} `
fs.appendFile("./data.txt",data,"utf-8",function(err,data){
    if(err){
        console.log("error",err)
    }else{
        console.log("avenger added")
    }
})

const USERS_REQUEST = "USERS_REQUEST";

let fetchUsers=()=>{
    return{
        type:USERS_REQUEST,
        
    }
};




const initialState={
    firstname:'',
    lastname:'',
    power:0,
    version:0
}

const reducer = (state = initialState, action)=>{
    switch(action.type){
        case USERS_REQUEST : return {     ...state,
                                                firstname:action.payload,
                                               lastname:action.payload,
                                                power:0,
                                                version:0
                                               
                                          }
                                            
      
        default : return state
        
    }
};

let thunkFetchUsers=()=>{
    return function(dispatch){
        dispatch(fetchUsers())
    }
}


const store = createStore(reducer);

let unsubscribe=store.subscribe(()=>console.log("Value :",store.getState()));


store.dispatch(fetchUsers(process.argv[2]))
