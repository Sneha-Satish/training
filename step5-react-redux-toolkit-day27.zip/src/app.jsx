import { Provider } from "react-redux";
import store from "./app/store";
import HeroView from "./features/hero/heroview";
import MovieView from "./features/movie/movieview";

let App=function(){
    return <div>
        <h2> </h2>
        <Provider store={store}>
            <HeroView/>
            <MovieView/>
        </Provider>
    </div>
}

export default App;