import {useSelector,useDispatch} from "react-redux";
import { addHero,removeHero,setHero } from "../hero/heroSlice";
const HeroView=()=>{
    let numberOfHeroes=useSelector(state=>state.hero.numberOfHeroes);
    let dispatch=useDispatch();

    return <div>
        <h2> Number of Heroes is {numberOfHeroes} </h2>
        <button onClick={()=>dispatch(addHero())}>Add Hero</button>
        <button onClick={()=>dispatch(removeHero())}>Remove Hero</button>
        <button onClick={()=>dispatch(setHero(50))}>Set Hero</button>
    </div>
}

export default HeroView;