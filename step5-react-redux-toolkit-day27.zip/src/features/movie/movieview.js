import {useSelector,useDispatch} from "react-redux";
import { addMovie,removeMovie,setMovie } from "../movie/movieSlice";
const MovieView=()=>{
    let numberOfMovie=useSelector(state=>state.movie. numberOfmovie);
    let dispatch=useDispatch();

    return <div>
        <h2> Number of Movie is {numberOfMovie} </h2>
        <button onClick={()=>dispatch(addMovie())}>Add Movie</button>
        <button onClick={()=>dispatch(removeMovie())}>Remove Movie</button>
        <button onClick={()=>dispatch(setMovie(50))}>Set Movie</button>
    </div>
}

export default MovieView;