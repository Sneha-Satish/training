//first-step
import {createSlice} from "@reduxjs/toolkit";

                                                                   
import {addHero} from "../hero/heroSlice"

const initialState={
    numberOfmovie:0
}

const movieSlice=createSlice({
    name:"Movie",
    initialState:initialState,
    reducers:{
        addMovie:(state)=>{
            state.numberOfmovie++
        },
        removeMovie:(state)=>{
            state.numberOfmovie--
        },
        setMovie:(state,action)=>{
            state.numberOfmovie=action.payload
        }
    },
    extraReducers:{
        ['Hero/addHero']:(state)=>{
            state.numberOfmovie++
        }
    }
      

    // extraReducers:builder=>{
    //      builder.addCase(heroActions.addHero,state=>{
    //         state.numberOfmovie++
    //     })
    // }
    
    })

    export default movieSlice.reducer;
    export const{addMovie,removeMovie,setMovie}=movieSlice.actions;