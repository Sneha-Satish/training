//  import {createRoot} from "react-dom";
//  import App from "./app.component";

//  createRoot(document.getElementById("root")).render(<App/>)

import { Component } from "react";
import {createRoot} from "react-dom/client";


class AvengersList extends Component{
    avengers = ['Ironman','Batman','Thor','Spiderman'];
    render(){
        return <ul>{
                this.avengers.map(function(val, idx){
                    return <li key={idx}>{ val }</li>
                })
            }</ul>
    }
}
 
 
createRoot(document.getElementById("root"))
// .render( avengersList );
.render( <AvengersList/> );