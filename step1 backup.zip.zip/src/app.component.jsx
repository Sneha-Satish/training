const { Component } = require("react");

class App extends Component{
    render(){
        return <h1> welcome to Valtech </h1>
    }
};
export default App