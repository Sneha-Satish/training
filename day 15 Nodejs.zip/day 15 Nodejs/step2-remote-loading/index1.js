const ftech=require("fetch");
const fs=require("fs");

ftech.fetchUrl("https://www.valtech.com/",function(error,meta,data){
    if(error){
        console.log("error",error)
    }else{
        fs.writeFileSync("temp/temp.html",data,"utf-8");
    }
})