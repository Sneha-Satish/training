const http=require("http");
const fs=require("fs");
var compname="valtech";

let server=http.createServer((req,res)=>{
    if(req=="/favicon"){
        res.writeHead(200,{"Content-Type":"text/html"})
        res.write();
        res.end();
    }else if(req.url=="/"){
        let htmlcontent=fs.readFileSync("./index.html","utf-8");
        res.writeHead(200,{
            "Content-Type":"text/html"
        });
        res.write(htmlcontent.replace("{compname}",compname).replace("{compname}",compname));
        res.end();
    }else{
        fs.readFile("./"+req.url,"utf-8",function(error,data){
            if(error){
                res.writeHead(404,{"Content-Type":"text/html"})
                res.end("<h1> 404:No donuts</h1>")
            }else{
                res.writeHead(200,{"Content-Type":"text/html"})
                res.end(data.replace("{compname}",compname).replace("{compname}",compname));

            }
        })
    }
})

server.listen(2021,"localhost",function(error,data){
    if (error){
        console.log("error",error);
    }
})