import React from "react";
import { Platform, StyleSheet,  Text,  View } from "react-native";

const Flex = () => {
  return (
    <View style={[styles.container, {
     
      flexDirection: "column"
    }]}>
      <View style={{ flex: 2,backgroundColor: "#ff006e" }} >
      <Text style={{textAlign:"center",paddingTop:50, fontSize:50}}>Header</Text>
      </View>
      
      <View style={{ flex: 5,backgroundColor: "#f15bb5" }} >
      <Text style={{textAlign:"center",paddingTop:120, fontSize:50}}>Main View</Text>
      </View>
      <View style={{ flex: 3,backgroundColor: "#ffafcc"}} >
      <Text style={{textAlign:"center",paddingTop:100, fontSize:50}}>Footer</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingLeft:0,
    paddingRight:0,
    paddingBottom:0,
    borderColor:"blue",
    borderWidth:3,
    paddingTop:Platform.OS==="android"&&50 || Platform.OS==="ios"&&60

  },
});

export default Flex;