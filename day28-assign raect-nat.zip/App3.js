import { useState } from "react";
import ironman from "./images/ironman.jpg"
import wonderwoman from "./images/wonderwoman.jpg"
import blackpanther from "./images/blackpanther.jpg"
import thor from "./images/thor.jpg"
import { Button, Text,View,StyleSheet, Platform,Image } from "react-native";
export default function Avengers(){

  let [name,updateName] = useState({title:'',firstname:'',lastname:'',image:''})
  let changeImage=( img )=>{
    if(img ==="ironman"){
      updateName({
        title:"Ironman",
        firstname:"Tony",
        lastname:"Stark",
        image:ironman
      })
    }
    else if(img ==="thor"){
       updateName({
        title:"Thor",
        firstname:"Thor",
        lastname:"Odinson",
        image:thor
      })
    }
    else if(img ==="blackpanther"){
      updateName({
        title:"Blackpanther",
        firstname:"T",
        lastname:"Challa",
        image:blackpanther
      })
    }
    else{
      updateName({
        title:"wonderwoman",
        firstname:"Diana",
        lastname:"Princess",
        image:wonderwoman
      })
    }
  }
  return(    
    <View style={mystyle.viewstyle}>

      <View>
        <Text style={{fontSize:45, color: "crimson",padding:50}}>Avengers</Text>
      </View>
      <Text/>

      <View>

        <Text style={{fontSize:22}} >
        Title : {name.title}{"\n"}  
        Firstname: {name.firstname}{"\n"}
        Lastname: {name.lastname}</Text>
        <Image source={name.image}></Image>


      <View>
        <Button onPress={()=>changeImage("thor")} title="Thor" color={'blue'}></Button>
        <Text>  </Text>
        <Button onPress={()=>changeImage("blackpanther")} title="blackpanther" color={'black'}></Button>
        <Text> </Text>
      </View>
      <View >
        <Button onPress={()=>changeImage("ironman")} title="Ironman" color={'gold'}></Button> 
        <Text> </Text>
        <Button onPress={()=>changeImage("wonderwoman")} title="wonderwoman" color={'red'}></Button>
        <Text> </Text>
      
      </View>


      </View>

     </View>
   
  )
}
let mystyle = StyleSheet.create({
  viewstyle:{
    flex:1,justifyContent:'center',alignItems:'center',paddingTop: Platform.OS ==="android"?30:0
  }
})
