import {useParams} from "react-router-dom";
import hero from "./data.json";

function DetailsComp(){
    let params=useParams();
    let hid=params.id;
    //console.log(hid)
    return(
        <div> 
            <h1> Hero Component </h1>
            {
                hero.heroes.map((val,idx)=>{
                    if(val.id===hid){
                        return <div>
                          Name:  {val.name}<br/>
                          ID:{val.id}<br/>

                          <h1>Powerstats:</h1>
                          Intelligence:{val.powerstats.intelligence} <br/>
                          Speed:{val.powerstats.speed}<br/>
                          Power:{val.powerstats.power}<br/>
                          Strength:{val.powerstats.strength}<br/>
                          
                          <h1>Biography:</h1>
                          Full-Name:{val.biography["full-name"]}<br/>
                          Full-Name:{val.biography["place-of-birth"]}<br/>
                          Full-Name:{val.biography["budget"]}<br/>
                          Full-Name:{val.biography["earning"]}<br/>

                          <h1> Appereance:</h1>
                          Gender:{val.appearance.gender}<br/>
                          Race:{val.appearance.race}<br/>
                          Height:{val.appearance.height}<br/>
                          Eye-Color:{val.appearance["eye-color"]}<br/>
                        </div>

                    }
                })
            }
            </div>
    )
        }
            

export default DetailsComp;