const configure=require("@reduxjs/toolkit").configureStore;
const heroReducer=require("../features/hero/heroSlice");

const store=configure({
    reducer:{
        hero:heroReducer
    }
})

module.exports=store