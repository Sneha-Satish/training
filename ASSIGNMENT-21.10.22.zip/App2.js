import React, { useState } from "react";
import { Platform, Pressable, StyleSheet,  Text,  View } from "react-native";

const App = () => {
  let [color,setColor]=useState("");
  return (
    <View style={[styles.container, {
      float:"left",
      alignItems:"stretch"
      
    }]}>
     <View style={[styles.container,{backgroundColor:color,}]}>
      <Pressable onPress={()=>setColor("#ff006e")}>
      <View style={{ width:100,height:100,backgroundColor: "#ff006e" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#f15bb5")}>
      <View style={{ width:100,height:100,backgroundColor: "#f15bb5" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#ffafcc")}>
      <View style={{width:100,height:100,backgroundColor: "#ffafcc"}} />
      </Pressable>
      <Pressable onPress={()=>setColor("aliceblue")}>
      <View style={{width:100,height:100,backgroundColor:"aliceblue"}} />
      </Pressable>
      </View>
     </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "row",
    alignItems:"flex-end",
    padding: 50,
    paddingLeft:0,
    paddingRight:0,
    paddingBottom:0,
    paddingTop:Platform.OS==="android"&&50 || Platform.OS==="ios"&&60

  },
});

export default App;