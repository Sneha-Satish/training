<template>
<div>
  <h1>{{title.toUpperCase()}} </h1>
 <h2>{{year}}</h2>

 <hr>
 <h1 v-text="title"> </h1>
 <div v-html="messagetag"> </div>
 <div v-bind:class="dynamicClass"> Hello All </div>
 <div v-bind:id="dynamicId"> Hello Everyone </div>

 <button v-bind:disabled="show">Click Button</button> <br> <br>
 <input type="checkbox" v-model="show"/>
 <input type="text" v-model="title"/> <br> <br>
<fieldset v-bind:hidden="!show">
  <legend>Terms and Conditions </legend>
  <p>
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veritatis, quisquam. Illum reprehenderit temporibus nobis quas quam qui magni. Architecto, autem hic. Voluptates, explicabo! Est sunt adipisci dignissimos similique tenetur deserunt.
    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam labore officiis quas odit impedit veritatis dolor animi dolores, facilis beatae temporibus expedita aut doloribus eius incidunt cupiditate voluptatem, ex ipsum.
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur inventore quo a velit? Commodi, odit dolorem perferendis libero ratione possimus maiores ipsam minima ea! Commodi maiores temporibus tenetur nihil recusandae!
</p>
</fieldset>

<hr>
<div v-bind:class="['box','brdr']">
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam assumenda earum molestiae, vitae omnis illum quod quibusdam asperiores accusantium voluptate! Alias ad cumque vero asperiores. Beatae eligendi officiis nobis fugiat.
</div>
<div v-bind:class="{'pinkbox':gender==='female'}"> 
  Gender based Style
</div>
<button v-bind:data-sku="itemid">Item for sale</button>
<div v-bind:lang="speak">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus corporis minus id fugit dolores magnam recusandae eaque esse hic dolore! Impedit in earum ipsum suscipit consequatur dicta iste sunt esse?
</div>
</div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
   
  },
  data(){
    return{
      title:"Welcome to Valtech_",
      year:1983,
      messagetag:"<span> Welcome to your <u>life</u></span>",
      dynamicClass:"box",
      dynamicId:"box1",
      show:true,
      gender:'female',
      itemid:11111,
      speak:"en"
      
    }
  }
}
</script>

<style>
#root {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #f71ca3;
  margin-top: 60px;
}

.box{
 width: 300px;
 height: 150px;
 background-color:#40b2e7;
 color: rgb(228, 41, 41);
 text-align: center;
 line-height: 150px;
 margin: 10px;
}
#box1{
 width: 300px;
 height: 150px;
 background-color:#45f1da;
 color: rgb(146, 15, 87);
 text-align: center;
 line-height: 150px;
 margin: 10px;
 font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
.brdr{
  border: 2px dashed blue;
  overflow: auto;
}

.pinkbox{
 width: 300px;
 height: 150px;
 background-color:#dfb1db;
 color: rgb(146, 15, 37);
}
</style>
