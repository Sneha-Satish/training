let redux=require("redux");
let createStore=redux.legacy_createStore;

// action type is a constant type.
// action creator is a function that returns an action object
// reducer is a function which has a switch cases to all functions based on action type.
//initial state is a initial value of store object
// store is an object that stores all shared states of your application.
// subscribe/unsubscribe to listen to changes of the store
//dispatch is a method that can take action object.

//ACTION
const ADDHERO="ADDHERO";

//ACTION CREATOR
let addhero=function(){
    return{
        type:ADDHERO
    }
};

//INITIAL STATE
let initialState={
    numberofHeroes:0
}

//REDUCER
let reducer=(state=initialState,action)=>{
    switch(action.type){
        case ADDHERO:return{numberofHeroes:state.numberofHeroes+1}
        default : return state
    }
};

//STORE
let store=createStore(reducer);
console.log("initial value of store",store.getState());

//SUBSCRIBER and UNSUBSCRIBER
let unsubscribe=store.subscribe(()=>console.log("Subscribed",store.getState()));

//DISPATCH
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
unsubscribe();
store.dispatch(addhero());


