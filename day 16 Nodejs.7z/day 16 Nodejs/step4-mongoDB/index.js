const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");



let app=express();
app.use(express.json());


let Schema=mongoose.Schema;
let ObjectId=Schema.ObjectId;
let url="mongodb+srv://admin:5YH1xujykpmWYH0V@cluster0.vm3o2dc.mongodb.net/valtechdb?retryWrites=true&w=majority"

let hero=mongoose.model("Hero",Schema({
    id:ObjectId,
    title:String,
    firstname:String,
    lastname:String
}));

mongoose.connect(url).then(function(){
    console.log("db connected")
}).catch(function(){
    console.log("error",error)
});

app.get("/",function(req,res){
    hero.find().then(dbres=>{
        res.json(dbres);
    })
})

app.listen(8080,"localhost",function(){

})