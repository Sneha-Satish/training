const express=require("express");
let app=express();

//app.set("views","templates"); instead of view give templates
//app.set("view engine", "ejs");
var port=process.env.PORT||6000;
console.log(port);

app.get("/",(req,res)=>{
    //res.sendFile(__dirname+"/public/index.html");
    res.render("index.pug",{
        compname:"valtech",
        message: "where experienced are engineered",
        
    });
});
app.get("/about",(req,res)=>{
    //res.sendFile(__dirname+"/public/about.html");
    res.render("about.pug",{
        compname:"valtech",
       
    });
});
app.get("/contact",(req,res)=>{
    //res.sendFile(__dirname+"/public/contact.html");
    res.render("contact.pug",{
        compname:"valtech",
       
    });
});

app.listen(port,"localhost",function(error){
    if(error){
        console.log("error",error)
    }else{
        console.log(`server is now live on localhost: ${port}`);
    }
})