//first-step
const createSlice=require("@reduxjs/toolkit").createSlice;

const initialState={
    numberOfHeroes:0
}

const heroSlice=createSlice({
    name:"Hero",
    initialState:initialState,
    reducers:{
        addHero:(state)=>{
            state.numberOfHeroes++
        },
        removeHero:(state)=>{
            state.numberOfHeroes--
        },
        setHero:(state,action)=>{
            state.numberOfmovie=action.payload
        }
    }
})

module.exports=heroSlice.reducer; //default export
module.exports.heroActions=heroSlice.actions;