//first-step
// const createSlice=require("@reduxjs/toolkit").createSlice;

const { heroActions } = require("../hero/heroSlice");

// const initialState={
//     numberOfmovie:0
// }

// const movieSlice=createSlice({
//     name:"Movie",
//     initialState:initialState,
//     reducers:{
//         addMovie:(state)=>{
//             state.numberOfmovie++
//         },
//         removeMovie:(state)=>{
//             state.numberOfmovie--
//         },
//         setMovie:(state,action)=>{
//             state.numberOfmovie=action.payload
//         }
//     }
// })

// module.exports=movieSlice.reducer; //default export
// module.exports.movieActions=movieSlice.actions;

                                                                       // Extra Reducers.
const createSlice=require("@reduxjs/toolkit").createSlice;

const initialState={
    numberOfmovie:0
}

const movieSlice=createSlice({
    name:"Movie",
    initialState:initialState,
    reducers:{
        addMovie:(state)=>{
            state.numberOfmovie++
        },
        removeMovie:(state)=>{
            state.numberOfmovie--
        },
        setMovie:(state,action)=>{
            state.numberOfmovie=action.payload
        }
    },
      

    extraReducers:builder=>{
         builder.addCase(heroActions.addHero,state=>{
            state.numberOfmovie++
        })
    }
    
    })

module.exports=movieSlice.reducer; //default export
module.exports.movieActions=movieSlice.actions;