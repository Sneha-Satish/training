const redux = require("redux");
let createStore = redux.legacy_createStore;
let fs = require("fs")
let process = require("process");
const { argv } = require("process");
let text;
if(process.argv[2]){
text= `firstname: ${process.argv[2]}\n lastname: ${process.argv[3]}\n fullname:${process.argv[4]}\n city :${process.argv[5]}\n power :${process.argv[6]}\n version:${process.argv[7]}\n`
}else{
    text = "";
}
const AVENGERS_REQUEST = "AVENGERS_REQUEST"

let data = new Array();

fs.appendFile("data.txt",text, 'utf-8',(err)=>{ 
    if(err){
    console.log(err);
    }else {
    console.log("Contents of avengers file appended");
    
  }});

let fetchUsers = ()=>{
    return {
         type: AVENGERS_REQUEST,
         
    }
}


data.push( fs.readFileSync("data.txt","utf-8"))

let reducer = (state,action)=>{
    switch(action.type){
        case AVENGERS_REQUEST : return data;
        default : return state
    }
}

let store = createStore(reducer);

store.subscribe(()=>{
    console.log(store.getState());
});

store.dispatch(fetchUsers())