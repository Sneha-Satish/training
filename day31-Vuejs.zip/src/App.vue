<template>
  <div>
    <h1>{{title}}</h1>
    <input v-model="power" type="range">{{power}}
    <br>
    <input v-model="booster" type="range">{{booster}}
    <hr>
    <textarea v-model.trim="message"></textarea>
    <br>
    <p>Message:{{message}}</p>
  </div>

 
</template>

<script>


export default {
  data(){
    return{
      title:"Modifiers",
      power:0,
      booster:0  ,
      message:''   
  }
  }
  
}
 
  

</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  /* -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale; */
  /* text-align: center; */
  color: #2c3e50;
  margin-top: 60px;
  
}

</style>
