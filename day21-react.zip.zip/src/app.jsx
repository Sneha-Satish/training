import { Component } from "react";
import ChildComp from "./childcomp";

class App extends Component{
    render(){
        return <div>
            <h1> Application Component</h1>
            <ChildComp/>
        </div>
    }
}

export default App;