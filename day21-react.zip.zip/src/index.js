import App from "./app";
import {createRoot} from "react-dom"

createRoot(document.getElementById("root"))
.render(<App/>)