import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
    state={
        title:"Default Title",
        power:0
        
    }
    render(){
        return <div>
            <h3>Child Component</h3>
            <h4>Title:{this.state.title} </h4>
            <h4>Power:{this.state.power} </h4>
            
            <button onClick={()=>{
                this.setState({
                    title:"Changed"
                });
            }}>Change Title </button>
        </div>
    }
       
        }
    

    
export default ChildComp;