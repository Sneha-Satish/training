<template>

<div>
<p class="size-buttons-size-button size-buttons-size-button-default bb"><span class="size-buttons-size-strike-hide"></span><span class="size-buttons-unified-size"><!-- react-text: 177 -->S<!-- /react-text --></span></p>
<p class="size-buttons-size-button size-buttons-size-button-default bb"><span class="size-buttons-size-strike-hide"></span><span class="size-buttons-unified-size"><!-- react-text: 177 -->M<!-- /react-text --></span></p>
<p class="size-buttons-size-button size-buttons-size-button-default bb"><span class="size-buttons-size-strike-hide"></span><span class="size-buttons-unified-size"><!-- react-text: 177 -->ML<!-- /react-text --></span></p>
<p class="size-buttons-size-button size-buttons-size-button-default bb"><span class="size-buttons-size-strike-hide"></span><span class="size-buttons-unified-size"><!-- react-text: 177 -->L<!-- /react-text --></span></p>
<p class="size-buttons-size-button size-buttons-size-button-default bb"><span class="size-buttons-size-strike-hide"></span><span class="size-buttons-unified-size"><!-- react-text: 177 -->XL<!-- /react-text --></span></p>
<p class="size-buttons-size-button size-buttons-size-button-default bb"><span class="size-buttons-size-strike-hide"></span><span class="size-buttons-unified-size"><!-- react-text: 177 -->XXL<!-- /react-text --></span></p>

</div>


</template>
<script>
export default {
  name: 'App',
  components: {
   
  }
}
</script>

<style>

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
 
}
.bb{
  border-radius: 50%;
  background-color: aliceblue;
  width:50px;
  height: 50px;
  padding:15px;
  float: left;
  border:2px solid black;
  
}
.bb:hover{
  border-radius: 50%;
  background-color: rgb(14, 117, 165);
  width:50px;
  height: 50px;
  padding:15px;
  float: left;
  color: aliceblue;
}
</style>