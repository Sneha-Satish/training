let redux=require("redux");
let createStore=redux.legacy_createStore;

// action type is a constant type.
// action creator is a function that returns an action object
// reducer is a function which has a switch cases to all functions based on action type.
//initial state is a initial value of store object
// store is an object that stores all shared states of your application.
// subscribe/unsubscribe to listen to changes of the store
//dispatch is a method that can take action object.

const ADDVILLIAN="ADDVILLIAN"
const REMOVEVILLIAN="REMOVEVILLIAN"
const SETVILLIAN="SETVILLIAN"

let addvillian=function(){                                                  // STORE
    return{
        type:ADDVILLIAN
    }
};

let removevillian=function(){
    return{
        type:REMOVEVILLIAN
    }
};

let setvillian=function(num){
    return{
        type:SETVILLIAN,
        payload:num
    }
};

let initialState={
    numberofVillians:0
}

let reducer=(state=initialState,action)=>{
    switch(action.type){
        case ADDVILLIAN:return{numberofVillians:state.numberofVillians+1}
        case REMOVEVILLIAN:return{numberofVillians:state.numberofVillians-1}
        case SETVILLIAN:return{numberofVillians:action.payload}
        default : return state
    }

}

let store=createStore(reducer);
console.log("initial value of store",store.getState());

let unsubscribe=store.subscribe(()=>console.log("Subscribed",store.getState()));

store.dispatch(addvillian());
store.dispatch(addvillian());
store.dispatch(addvillian());
store.dispatch(removevillian());
store.dispatch(addvillian());
store.dispatch(addvillian());
store.dispatch(removevillian());
store.dispatch(setvillian(6));

