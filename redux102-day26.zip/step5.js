let redux=require("redux");
const logger=require("redux-logger").createLogger;
let createStore=redux.legacy_createStore;
let combineReducers=redux.combineReducers;
let bindActionCreators=redux.bindActionCreators;

let applyMiddleware=redux.applyMiddleware;
// let logger=createlogger();

// action type is a constant type.
// action creator is a function that returns an action object
// reducer is a function which has a switch cases to all functions based on action type.
//initial state is a initial value of store object
// store is an object that stores all shared states of your application.
// subscribe/unsubscribe to listen to changes of the store
//dispatch is a method that can take action object.

const ADDVILLIAN="ADDVILLIAN"
const REMOVEVILLIAN="REMOVEVILLIAN"
const SETVILLIAN="SETVILLIAN"

const ADDMOVIES="ADDMOVIES"                                        //MIDDLEWARE CONCEPT
const REMOVEMOVIES="REMOVEMOVIES"
const SETMOVIES="SETMOVIES"

let addvillian=function(){
    return{
        type:ADDVILLIAN
    }
};

let removevillian=function(){
    return{
        type:REMOVEVILLIAN
    }
};

let setvillian=function(num){
    return{
        type:SETVILLIAN,
        payload:num
    }
};

let addmovies=function(){
    return{
        type:ADDMOVIES
    }
};

let removemovies=function(){
    return{
        type:REMOVEMOVIES
    }
};

let setmovies=function(num){
    return{
        type:SETMOVIES,
        payload:num
    }
};

let initialVState={
    numberofVillians:0

}
let initialMState={
    numberofMovies:0

}

let villianReducer=(state=initialVState,action)=>{
    switch(action.type){
        case ADDVILLIAN:return{numberofVillians:state.numberofVillians+1}
        case REMOVEVILLIAN:return{numberofVillians:state.numberofVillians-1}
        case SETVILLIAN:return{numberofVillians:action.payload}
        default : return state
    }

}

let movieReducer=(state=initialMState,action)=>{
    switch(action.type){
        case ADDMOVIES:return{numberofMovies:state.numberofMovies+1}
        case REMOVEMOVIES:return{numberofMovies:state.numberofMovies-1}
        case SETMOVIES:return{numberofMovies:action.payload}
        default : return state
    }

}

let rootReducer=combineReducers({
    villians:villianReducer,
    movies:movieReducer
});

let store=createStore(rootReducer,applyMiddleware(logger()));
console.log("initial value of store",store.getState());

let unsubscribe=store.subscribe(()=>console.log("Subscribed",store.getState()));

let action=bindActionCreators({addmovies,removemovies,setmovies,addvillian,removevillian,setvillian},store.dispatch)

// store.dispatch(addvillian());
// store.dispatch(addvillian());
// store.dispatch(addvillian());
// store.dispatch(removevillian());
// store.dispatch(addvillian());
// store.dispatch(addvillian());
// store.dispatch(removevillian());
// store.dispatch(setvillian(6));
// // -----------------------------------
// store.dispatch(addmovies());
// store.dispatch(addmovies());
// store.dispatch(addmovies());
// store.dispatch(removemovies());
// store.dispatch(addmovies());
// store.dispatch(addmovies());
// store.dispatch(removemovies());
// store.dispatch(setmovies(6));

store.dispatch(addmovies());
 store.dispatch(addmovies());
store.dispatch(removemovies());
 store.dispatch(addvillian());
 store.dispatch(addvillian());
 store.dispatch(removevillian());
 store.dispatch(setvillian(10));
 store.dispatch(setmovies(6));

