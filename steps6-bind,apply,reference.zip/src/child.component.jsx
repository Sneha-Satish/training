import { Component } from "react";


class ChildComp extends Component{
    state={
        title:"Default Title",
        power:0
        
    }

    increasePower=()=>{
        this.setState({
            power:this.state.power+1
        });
    }

    setpower=(evt)=>{
        this.setState({
            power:Number(evt.target.value)
        });

    }

    changepower=()=>{
        this.setState({
            power:Number(this.elm.currentvalue)
        });
    }
    render(){
        return <div>
            <h3>Child Component</h3>
            <h4>Title:{this.state.title} </h4>
            <h4>Power:{this.state.power} </h4>

            {/*<button onClick={this.increasePower.bind(this)}> Change Power</button>*/}
            <button onClick={()=>this.increasePower()}>increasePower</button> <br/>
            <input type="Range"></input>
            <button onClick={()=>{
                this.setState({
                    title:"Changed"
                });
            }}>Change Title </button>
            <br/>
            <input ref={this.elm} type="number"/>
            <button onClick={this.changepower}>Change </button>
        </div>
    }
       
        }
    

    
export default ChildComp;