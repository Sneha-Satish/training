<template>    
    <div class="box">
        <h2>Parent Component</h2>
        <h3>{{message}}</h3>
        <FamChild/>
    </div>
</template>
 
<script>
    import FamChild from "./child.vue";
    export default {
        name : "FamParent",
        inject:['message'],

        components: { 
          FamChild
        }
    }
</script>
<style>
 
</style>