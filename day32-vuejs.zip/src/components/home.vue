<template>
    <div>
      <h1>Title: {{title}} | Version{{version}}</h1>
    </div>
  </template>
  <script>
    export default {
    name:"HomeComp",
    props:['title','version']
     
  }
  </script>
  <style>
  
  </style>
   