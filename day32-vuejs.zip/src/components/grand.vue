 
<template>    
    <div class="box">
        <h2>Grand Parent Component</h2>
        <input v-model="changeMessage" type="text"/>
               <FamParent/>
    </div>
</template>
 
<script>
    import FamParent from "./parent.vue"
    export default {
        name : "FamGrand",
        components: { 
          FamParent
        },
        provide : {
            message : ' '
        },
        methods : {
          changeMessage(nmes){
          console.log("message was called");
          return this.message=nmes;
        }
      },
    }
</script>
 
<style>
   .box{
    border:  2px solid rgb(124, 21, 21);
    padding: 10px;
    margin: 10px;
    text-align: left;
    max-width: 600px;
   }
</style>