<!-- <template>
  <div>
   <HomeComp :version="appversion" title="Avengers"/>
  </div>
 
 </template>
<script>
import HomeComp from "./components/home.vue";

  export default {
    name : "App",
    data(){
      return{
        power:0,
        appversion:5
      }
    },
    components:{
      HomeComp
    }
   
}
</script>
<style>
 #app{
  
  color: rgb(51, 7, 250);
 }
</style>
  -->

<!--   
<template>
  <div>
    <FamGrand/>
  </div>
</template>
<script>
import FamGrand from "./components/grand.vue";
 
export default{
  data(){
    return {
    
    }
  },
  components :{
    FamGrand
  }
}
</script>
<style></style> -->


<template>  
  <div>
    <pre>{{ JSON.stringify(users,null,1) }}</pre>
    <button @click="getUsers">Get Data</button>
  </div>
</template>

<script>
import axios from "axios";
  export default {
   name : "AppUsers",
    data(){
      return {
        users : []
      }
    },
    methods : {
     getUsers(){
        axios.get("https://reqres.in/api/users?page=2")
        .then( res => this.users = res.data.data )
        .catch( err => console.log( err ))
    
    }
  }
}
</script>

<style>

</style>