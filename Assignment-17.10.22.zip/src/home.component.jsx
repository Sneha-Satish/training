import {BrowserRouter,Routes,Route,Link} from "react-router-dom";
import hero from "./data.json";

function HomeComp(){
    return <div> 
        {
        hero.heroes.map((val,idx)=>{
            return  <ul>
            <li> <Link to={"/details/"+val.id}>{val.name}</Link></li>
        </ul>
        })
}
 </div>
}

export default HomeComp;