import {BrowserRouter,Routes,Route,Link} from "react-router-dom";
import DetailsComp from "./details.component";

import HomeComp from "./home.component";

function App(){
    return(
        <div>
          <h1>Heroes List</h1>
            <BrowserRouter>
              
           
            <Routes>
                <Route path="/" element={<HomeComp/>} />
                <Route path="/details/:id" element={<DetailsComp/>} />
            </Routes>
            </BrowserRouter>
        </div>
    )    
}

export default App;