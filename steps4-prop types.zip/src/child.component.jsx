import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{

    static PropTypes={
        title:PropTypes.string.isRequired,
        power:PropTypes.number.isRequired,
        version:PropTypes.number.isRequired,}

        render(){
            return <div>
                <h2> Title:{this.props.title} </h2>
                <h2> Version:{this.props.version} </h2>
                <h4> power: {this.props.version} </h4>
            </div>
        }
       
        }
    

    
export default ChildComp;