import { Component } from "react";
import ChildComp from "./child.component";

class App extends Component{
    render(){
        return <div>
            <ChildComp title="first component" version={1}> </ChildComp>
            <ChildComp title="second component" version={2}> </ChildComp>
            <ChildComp title="third component" power={8}> </ChildComp> 
            
            
        </div>
    }
}

export default App;
